import passwordcrack
import pydefender
import metadata
import menu
import installer
