import menu
import installer
installer.first_run()
menu.menu()
